#!/usr/bin/python

import os
print ("Fusion3-Download v.0.1")
print ("")
print ("Choose your language:")
print ("")
print ("1. English (Alpha)")
print ("2. Russian (Recommended and by default)")
question = raw_input("?: ")
if question == "1":
    os.system('python res/en/hello.py')
else:
    if question == "2":
        os.system('python res/ru/hello.py')
    else:
        os.system('python res/ru/hello.py')
