#!/usr/bin/python
# -*- coding: utf-8

import os

print ("Вы выбрали Sony Xperia ZR!")
print ("Выберите ветку")
print ("1. Pie")
print ("2. Oreo")
print ("2. Nougat")
print ("2. Marshmallow")
print ("2. Lollipop")

question = raw_input("Номер: ")
if question == "1":
    os.system('python devices_configuration/zr/android_version/pie.py')
else:
    from git import Repo
    Repo.clone_from("https://github.com/fusion3-common/android_device_sony_dogo.git", "F3Downloads/SonyZR/device/sony/dogo")
    Repo.clone_from("https://github.com/fusion3-common/android_device_sony_fusion3-common.git", "F3Downloads/SonyZR/device/sony/fusion3-common")
    Repo.clone_from("https://github.com/fusion3-common/android_device_sony_fusion3-common.git", "F3Downloads/SonyZR/device/sony/fusion3-common")
