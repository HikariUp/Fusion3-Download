#!/usr/bin/python
# -*- coding: utf-8

from git import Repo

Repo.clone_from("https://github.com/fusion3-common/android_device_sony_dogo.git", "F3Downloads/SonyZR/device/sony/dogo")
#Repo.clone_from("https://github.com/fusion3-common/android_device_sony_fusion3-common.git", "F3Downloads/SonyZR/device/sony/fusion3-common")
#Repo.clone_from("https://github.com/fusion3-common/android_device_sony_fusion3-common.git", "F3Downloads/SonyZR/device/sony/fusion3-common")
