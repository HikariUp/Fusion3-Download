#!/usr/bin/python
# -*- coding: utf-8

import os

print ("")
print ("Что будет скачено:")
print ("Kernel, Dogo, Fusion3-common, Common, Vendor, DASH, Thermanager")
print ("Вы готовы?")
print ("1. Да?")

question = raw_input("Номер: ")
if question == "1":
    os.system('python res/devices_configuration/zr/android_version/repo/pie.py')
else:
    if question == "2":
        print ("ok 2")
    else:
        if question == "3":
            print ("ok 3")
        else:
            print ("Exit")

os.system('python res/ru/end.py')
