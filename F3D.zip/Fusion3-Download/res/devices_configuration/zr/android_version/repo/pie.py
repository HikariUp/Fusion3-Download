#!/usr/bin/python
# -*- coding: utf-8

#import subprocess
from git import Repo

print (" * Kernel * ")
Repo.clone_from("https://github.com/fusion3-common/android_kernel_sony_apq8064.git", "F3Downloads/SonyZR/kernel/sony/apq8064", branch="lineage-16.0")
print (" * Dogo * ")
Repo.clone_from("https://github.com/fusion3-common/android_device_sony_dogo.git", "F3Downloads/SonyZR/device/sony/dogo", branch="lineage-16.0")
print (" * Fusion3-Common * ")
Repo.clone_from("https://github.com/fusion3-common/android_device_sony_fusion3-common.git", "F3Downloads/SonyZR/device/sony/fusion3-common", branch="lineage-16.0")
print (" * Vendor Sony * ")
Repo.clone_from("https://github.com/fusion3-common/proprietary_vendor_sony.git", "F3Downloads/SonyZR/vendor/sony", branch="lineage-16.0")
print (" * Common * ")
Repo.clone_from("https://github.com/LineageOS/android_device_sony_common.git", "F3Downloads/SonyZR/device/sony/common", branch="lineage-16.0")
print (" * DASH * ")
Repo.clone_from("https://github.com/LineageOS/android_hardware_sony_DASH.git", "F3Downloads/SonyZR/hardware/sony/DASH", branch="lineage-16.0")
print (" * Thermanager * ")
Repo.clone_from("https://github.com/LineageOS/android_hardware_sony_thermanager.git", "F3Downloads/SonyZR/hardware/sony/thermanager", branch="lineage-16.0")
print ("")
print (" =) ")
print ("")

#Скачивает отдельную папку vendor, скачивается не в то место
#p = subprocess.Popen("svn export https://github.com/fusion3-common/proprietary_vendor_sony/branches/lineage-16.0/dogo --force", stdout=subprocess.PIPE, shell=True)
