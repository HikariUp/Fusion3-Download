#!/usr/bin/python
# -*- coding: utf-8

import os

print ("Вы выбрали Sony Xperia ZR!")
print ("Выберите ветку")
print ("1. Pie +")
print ("2. Oreo -")
print ("3. Nougat -")
print ("4. Marshmallow -")
print ("5. Lollipop -")

question = raw_input("Номер: ")
if question == "1":
    os.system('python res/devices_configuration/zr/android_version/pie_conf.py')
else:
    if question == "2":
        os.system('python res/devices_configuration/zr/android_version/oreo_conf.py')
    else:
        if question == "3":
            os.system('python res/devices_configuration/zr/android_version/nougat_conf.py')
        else:
            if question == "4":
                os.system('python res/devices_configuration/zr/android_version/marshmallow_conf.py')
            else:
                if question == "5":
                    os.system('python res/devices_configuration/zr/android_version/lollipop_conf.py')
                else:
                    os.system('python res/ru/choose_device.py')
