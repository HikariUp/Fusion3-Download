#!/usr/bin/python

import os

print ("**************************************************************************************************")
print ("*       (c) HikariUp for GitHub(Xperia Fusion3)                                                  *")
print ("*                                                                                                *")
print ("* Hello!                                                                                         *")
print ("* This script is used to help with the Assembly of the Android OS for devices based on Fusion 3! *")
print ("*                                                                                                *")
print ("**************************************************************************************************")

os.system('python res/en/choose_device.py')
