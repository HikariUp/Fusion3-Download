#!/usr/bin/python

import os

print ("Select your device to continue:")
print ("")
print ("1. Xperia Z")
print ("2. Xperia ZL")
print ("3. Xperia ZR")
print ("")

question = raw_input("Number: ")
if question == "1":
    print ("ok 1")
else:
    if question == "2":
        print ("ok 2")
    else:
        if question == "3":
            os.system('python res/devices_configuration/zr/conf.py')
        else:
            os.system('python res/ru/choose_device.py')
