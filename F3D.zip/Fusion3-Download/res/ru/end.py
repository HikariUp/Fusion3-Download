#!/usr/bin/python
# -*- coding: utf-8

import os

print ("")
print ("Если вы видите =), то с большой вероятностью, все файлы скачались правильно!")
print ("")
print ("Скачивание прошло успешно?")
print ("1. Да")
print ("2. Нет")
print ("")
question = raw_input("Номер: ")
if question == "1":
    print ("Хотите вернуться к началу?")
    print ("1. Да")
    print ("2. Нет")
    question = raw_input("Номер: ")
    if question == "1":
        os.system('python res/ru/hello.py')
    else:
        print ("Спасибо, что использовали мою программу")
        print ("Написание этой программы заняло довольно много времени")
        print ("Так что, если хочешь, то можешь поддержать меня: ")
        print ("Yandex.Кошелёк: 4100 1538 3400 262")
        print ("Ну или просто сказать спасибо :)")
else:
    if question == "2":
        print ("Хотите начать скачивание заново или сообщить об ошибке?")
        print ("1. Начать заново")
        print ("2. Сообщить об ошибке")
        question = raw_input("Номер: ")
        if question == "1":
            os.system('python res/devices_configuration/zr/android_version/pie_conf.py')
        else:
            print ("Есть несколько способов, как со мной связаться:")
            print ("ВК: https://vk.com/id434261253")
            print ("Mail: solodyankin.daniil@yandex.ru")
            print ("Tlgrm: hikari_top")
